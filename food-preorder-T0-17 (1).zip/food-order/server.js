// Student Order Placement & Confirmation (Jira T0-17)
// Express API plus a static front end in /public.

const path = require('path');
const express = require('express');
const { openDatabase } = require('./db');

const MAX_QUANTITY = 20;

function makeOrderNumber(store, now) {
  const day = now.toISOString().slice(0, 10).replace(/-/g, '');
  const [{ n }] = store.all(
    "SELECT COUNT(*) AS n FROM orders WHERE order_number LIKE ?",
    [`ORD-${day}-%`]
  );
  return `ORD-${day}-${String(n + 1).padStart(4, '0')}`;
}

// Checks the cart and works out the total on the server, so a student
// can't change prices from the browser.
function validateOrder(store, body) {
  const errors = [];
  const studentId = typeof body.studentId === 'string' ? body.studentId.trim() : '';
  if (!studentId) errors.push('Student ID is required.');

  const items = Array.isArray(body.items) ? body.items : [];
  if (items.length === 0) errors.push('Your cart is empty.');

  const lines = [];
  const seen = new Set();
  for (const raw of items) {
    const id = Number(raw.menuItemId);
    const qty = Number(raw.quantity);
    if (!Number.isInteger(id) || seen.has(id)) {
      errors.push('Each cart item must be a different menu item.');
      continue;
    }
    seen.add(id);
    if (!Number.isInteger(qty) || qty < 1 || qty > MAX_QUANTITY) {
      errors.push(`Quantity must be a whole number from 1 to ${MAX_QUANTITY}.`);
      continue;
    }
    const [menuItem] = store.all('SELECT * FROM menu_items WHERE id = ?', [id]);
    if (!menuItem) {
      errors.push(`Menu item ${id} does not exist.`);
      continue;
    }
    if (!menuItem.available) {
      errors.push(`${menuItem.name} is sold out.`);
      continue;
    }
    lines.push({ menuItem, quantity: qty, lineTotal: menuItem.price * qty });
  }

  const total = lines.reduce((sum, l) => sum + l.lineTotal, 0);
  return { errors, studentId, lines, total };
}

function getOrder(store, orderNumber) {
  const [order] = store.all('SELECT * FROM orders WHERE order_number = ?', [orderNumber]);
  if (!order) return null;
  const items = store.all(
    'SELECT name, unit_price AS unitPrice, quantity FROM order_items WHERE order_id = ?',
    [order.id]
  );
  return {
    orderNumber: order.order_number,
    studentId: order.student_id,
    total: order.total,
    status: order.status,
    createdAt: order.created_at,
    items,
  };
}

async function createApp({ dbFile } = {}) {
  const store = await openDatabase(dbFile);
  const app = express();
  app.use(express.json());
  app.use(express.static(path.join(__dirname, 'public')));

  app.get('/api/menu', (req, res) => {
    res.json(store.all('SELECT id, name, price, category, available FROM menu_items ORDER BY category, name'));
  });

  // Review step: returns the priced cart without saving anything.
  app.post('/api/orders/preview', (req, res) => {
    const { errors, lines, total } = validateOrder(store, req.body || {});
    if (errors.length) return res.status(400).json({ errors });
    res.json({
      items: lines.map(l => ({ name: l.menuItem.name, unitPrice: l.menuItem.price, quantity: l.quantity, lineTotal: l.lineTotal })),
      total,
    });
  });

  app.post('/api/orders', (req, res) => {
    const { errors, studentId, lines, total } = validateOrder(store, req.body || {});
    if (errors.length) return res.status(400).json({ errors });

    const now = new Date();
    const orderNumber = makeOrderNumber(store, now);
    try {
      store.db.run('BEGIN');
      store.db.run(
        'INSERT INTO orders (order_number, student_id, total, created_at) VALUES (?, ?, ?, ?)',
        [orderNumber, studentId, total, now.toISOString()]
      );
      const [{ id: orderId }] = store.all('SELECT last_insert_rowid() AS id');
      for (const l of lines) {
        store.db.run(
          'INSERT INTO order_items (order_id, menu_item_id, name, unit_price, quantity) VALUES (?, ?, ?, ?, ?)',
          [orderId, l.menuItem.id, l.menuItem.name, l.menuItem.price, l.quantity]
        );
      }
      store.db.run('COMMIT');
      store.save();
    } catch (err) {
      store.db.run('ROLLBACK');
      return res.status(500).json({ errors: ['Could not save your order. Please try again.'] });
    }

    res.status(201).json({ message: 'Your order has been placed.', order: getOrder(store, orderNumber) });
  });

  app.get('/api/orders/:orderNumber', (req, res) => {
    const order = getOrder(store, req.params.orderNumber);
    if (!order) return res.status(404).json({ errors: ['Order not found.'] });
    res.json(order);
  });

  return { app, store };
}

if (require.main === module) {
  const port = process.env.PORT || 3000;
  createApp({ dbFile: path.join(__dirname, 'data', 'food.db') }).then(({ app }) => {
    app.listen(port, () => console.log(`Food pre-order running at http://localhost:${port}`));
  });
}

module.exports = { createApp };
