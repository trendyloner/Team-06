// Database layer for the order placement module (T0-17).
// Uses sql.js so there's no native build step. The database is kept in memory
// and written to disk after every change.

const fs = require('fs');
const path = require('path');
const initSqlJs = require('sql.js');

const SEED_MENU = [
  { name: 'Chapati & Beans', price: 120, category: 'Mains' },
  { name: 'Rice & Beef Stew', price: 200, category: 'Mains' },
  { name: 'Ugali & Sukuma', price: 100, category: 'Mains' },
  { name: 'Pilau', price: 180, category: 'Mains' },
  { name: 'Mandazi (2 pcs)', price: 30, category: 'Snacks' },
  { name: 'Samosa', price: 40, category: 'Snacks' },
  { name: 'Chai', price: 30, category: 'Drinks' },
  { name: 'Passion Juice', price: 60, category: 'Drinks' },
];

async function openDatabase(filePath) {
  const SQL = await initSqlJs();
  let db;

  if (filePath && fs.existsSync(filePath)) {
    db = new SQL.Database(fs.readFileSync(filePath));
  } else {
    db = new SQL.Database();
  }

  db.run(`
    CREATE TABLE IF NOT EXISTS menu_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      price INTEGER NOT NULL,
      category TEXT NOT NULL,
      available INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_number TEXT NOT NULL UNIQUE,
      student_id TEXT NOT NULL,
      total INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'Received',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL REFERENCES orders(id),
      menu_item_id INTEGER NOT NULL REFERENCES menu_items(id),
      name TEXT NOT NULL,
      unit_price INTEGER NOT NULL,
      quantity INTEGER NOT NULL
    );
  `);

  const count = db.exec('SELECT COUNT(*) FROM menu_items')[0].values[0][0];
  if (count === 0) {
    const stmt = db.prepare('INSERT INTO menu_items (name, price, category) VALUES (?, ?, ?)');
    for (const item of SEED_MENU) stmt.run([item.name, item.price, item.category]);
    stmt.free();
  }

  function save() {
    if (!filePath) return;
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(filePath, Buffer.from(db.export()));
  }

  function all(sql, params = []) {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    const rows = [];
    while (stmt.step()) rows.push(stmt.getAsObject());
    stmt.free();
    return rows;
  }

  save();
  return { db, all, save };
}

module.exports = { openDatabase };
