# Campus Food Pre-Order: Order Placement & Confirmation

Jira story **T0-17**, Team 06. A student picks food from the menu, sets quantities, reviews the order and gets a confirmation with an order number.

## Run it

```
npm install
npm start
```

Open http://localhost:3000. Run the tests with `npm test`.

Needs Node 18 or newer. The database is a single file at `data/food.db`, created and filled with a sample menu on first start. Delete it to reset.

## How the acceptance criteria are covered

| Acceptance criterion | Where it lives | Test |
|---|---|---|
| Student can select food items from the available menu | `GET /api/menu`, menu grid in `public/app.js`. Sold-out items can't be added. | AC1 |
| Student can set the quantity of each selected item | `+` and `−` controls in the cart, limited to 1 to 20 and checked again on the server | AC2 |
| The system calculates the total order amount | `validateOrder()` in `server.js`. Prices always come from the database, never the browser. | AC3 |
| Student can review the order before submitting it | `POST /api/orders/preview` and the review screen. Nothing is saved at this step. | AC4 |
| Confirmation with an order number once the order is placed | `POST /api/orders` saves the order and returns a number like `ORD-20261012-0001` | AC5 |

## API

| Method | Path | What it does |
|---|---|---|
| GET | `/api/menu` | All menu items with price and availability |
| POST | `/api/orders/preview` | Prices the cart for the review screen, saves nothing |
| POST | `/api/orders` | Places the order, returns the confirmation |
| GET | `/api/orders/:orderNumber` | One order with its items and status |

Order body:

```json
{ "studentId": "CS/MG/1234/09/24", "items": [{ "menuItemId": 1, "quantity": 2 }] }
```

## Fitting it into the team app

The student ID is typed in for now. Once this is merged with the login work (T0-3), take it from the logged-in session instead. The `menu_items` table is a stand-in for whatever the menu stories (T0-11 to T0-15) create, so point the queries at that table. Each order is saved with `student_id`, `status` and `created_at`, which is what Order History (T0-18) and Cancel Order (T0-19) need.
