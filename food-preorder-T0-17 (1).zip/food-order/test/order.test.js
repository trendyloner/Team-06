// Tests for T0-17, one group per acceptance criterion. Run with: npm test
const { test, before, after } = require('node:test');
const assert = require('node:assert');
const { createApp } = require('../server');

let server, base, store;

before(async () => {
  const created = await createApp(); // in-memory database, nothing written to disk
  store = created.store;
  await new Promise(resolve => {
    server = created.app.listen(0, () => {
      base = `http://localhost:${server.address().port}`;
      resolve();
    });
  });
});
after(() => server.close());

const post = (path, body) =>
  fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
    .then(async r => ({ status: r.status, body: await r.json() }));

test('AC1: student can select food items from the available menu', async () => {
  const menu = await fetch(base + '/api/menu').then(r => r.json());
  assert.ok(menu.length > 0);
  assert.ok(menu.every(m => m.id && m.name && m.price > 0));

  // A sold-out item cannot be ordered
  store.db.run('UPDATE menu_items SET available = 0 WHERE id = 1');
  const res = await post('/api/orders', { studentId: 'S1', items: [{ menuItemId: 1, quantity: 1 }] });
  assert.strictEqual(res.status, 400);
  assert.match(res.body.errors.join(' '), /sold out/);
  store.db.run('UPDATE menu_items SET available = 1 WHERE id = 1');
});

test('AC2: student can set the quantity of each selected item', async () => {
  const ok = await post('/api/orders/preview', { studentId: 'S1', items: [{ menuItemId: 2, quantity: 3 }] });
  assert.strictEqual(ok.status, 200);
  assert.strictEqual(ok.body.items[0].quantity, 3);

  for (const bad of [0, -1, 1.5, 21]) {
    const res = await post('/api/orders/preview', { studentId: 'S1', items: [{ menuItemId: 2, quantity: bad }] });
    assert.strictEqual(res.status, 400, `quantity ${bad} should be rejected`);
  }
});

test('AC3: the system calculates the total order amount', async () => {
  const menu = await fetch(base + '/api/menu').then(r => r.json());
  const [a, b] = menu;
  const expected = a.price * 2 + b.price * 3;
  const res = await post('/api/orders/preview', {
    studentId: 'S1',
    items: [{ menuItemId: a.id, quantity: 2 }, { menuItemId: b.id, quantity: 3 }],
  });
  assert.strictEqual(res.body.total, expected);

  // A price sent from the browser is ignored
  const tampered = await post('/api/orders/preview', {
    studentId: 'S1', items: [{ menuItemId: a.id, quantity: 1, price: 1 }],
  });
  assert.strictEqual(tampered.body.total, a.price);
});

test('AC4: student can review the order before submitting it', async () => {
  const before = store.all('SELECT COUNT(*) AS n FROM orders')[0].n;
  const res = await post('/api/orders/preview', { studentId: 'S1', items: [{ menuItemId: 3, quantity: 1 }] });
  assert.strictEqual(res.status, 200);
  assert.ok(res.body.items[0].name);
  const afterCount = store.all('SELECT COUNT(*) AS n FROM orders')[0].n;
  assert.strictEqual(afterCount, before, 'previewing must not save an order');
});

test('AC5: confirmation with an order number once the order is placed', async () => {
  const res = await post('/api/orders', { studentId: 'S2', items: [{ menuItemId: 4, quantity: 2 }] });
  assert.strictEqual(res.status, 201);
  assert.match(res.body.order.orderNumber, /^ORD-\d{8}-\d{4}$/);
  assert.strictEqual(res.body.order.status, 'Received');

  // The order is saved and can be looked up again
  const saved = await fetch(`${base}/api/orders/${res.body.order.orderNumber}`).then(r => r.json());
  assert.strictEqual(saved.studentId, 'S2');
  assert.strictEqual(saved.items[0].quantity, 2);

  // Order numbers are unique
  const second = await post('/api/orders', { studentId: 'S2', items: [{ menuItemId: 4, quantity: 1 }] });
  assert.notStrictEqual(second.body.order.orderNumber, res.body.order.orderNumber);
});

test('rejects an empty cart or a missing student ID', async () => {
  assert.strictEqual((await post('/api/orders', { studentId: 'S1', items: [] })).status, 400);
  assert.strictEqual((await post('/api/orders', { items: [{ menuItemId: 1, quantity: 1 }] })).status, 400);
});
